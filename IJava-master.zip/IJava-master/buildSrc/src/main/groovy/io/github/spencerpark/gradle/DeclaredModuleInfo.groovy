package io.github.spencerpark.gradle

class DeclaredModuleInfo {
    String projectUrl
    String license
    String licenseUrl
}
